module lista

go 1.26.8
